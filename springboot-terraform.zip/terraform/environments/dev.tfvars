# ─────────────────────────────────────────────
# environments/dev.tfvars
# Usage: terraform apply -var-file="environments/dev.tfvars"
# ─────────────────────────────────────────────

project_name = "springboot-app"
environment  = "dev"
aws_region   = "ap-south-1"
owner        = "platform-team"

# Networking
vpc_cidr             = "10.0.0.0/16"
availability_zones   = ["ap-south-1a", "ap-south-1b"]
public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
private_subnet_cidrs = ["10.0.10.0/24", "10.0.11.0/24"]
db_subnet_cidrs      = ["10.0.20.0/24", "10.0.21.0/24"]
enable_nat_gateway   = true
single_nat_gateway   = true   # Cost saving in dev

# DNS / CloudFront
domain_name            = "dev.example.com"
cloudfront_price_class = "PriceClass_100"
waf_rate_limit         = 1000

# ALB
alb_deletion_protection = false
alb_idle_timeout        = 60

# Frontend ASG
frontend_ami_id           = "ami-0c55b159cbfafe1f0"   # Replace with your AMI
frontend_instance_type    = "t3.micro"
frontend_min_size         = 1
frontend_max_size         = 2
frontend_desired_capacity = 1
frontend_scale_out_cron   = "0 3 * * MON-FRI"    # 08:30 IST
frontend_scale_in_cron    = "0 14 * * MON-FRI"   # 19:30 IST

# Backend ASG
backend_ami_id            = "ami-0c55b159cbfafe1f0"   # Replace with your AMI
backend_instance_type     = "t3.small"
backend_min_size          = 1
backend_max_size          = 2
backend_desired_capacity  = 1
backend_app_port          = 8080
backend_scale_out_cron    = "0 3 * * MON-FRI"
backend_scale_in_cron     = "0 14 * * MON-FRI"

# RDS
db_engine                = "mysql"
db_engine_version        = "8.0"
db_instance_class        = "db.t3.micro"
db_allocated_storage     = 20
db_max_allocated_storage = 50
db_name                  = "springbootdb_dev"
db_username              = "admin"
db_multi_az              = false
db_backup_retention_period = 1
db_deletion_protection   = false

# S3
s3_force_destroy      = true
s3_versioning_enabled = false

# CloudWatch
log_retention_days  = 7
alarm_email         = "dev-alerts@example.com"
cpu_alarm_threshold = 85

# Slack
slack_channel = "#dev-alerts"

# Key Pair
key_pair_name = "springboot-dev-key"
