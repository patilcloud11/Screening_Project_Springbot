# ─────────────────────────────────────────────
# environments/prod.tfvars
# Usage: terraform apply -var-file="environments/prod.tfvars"
# ─────────────────────────────────────────────

project_name = "springboot-app"
environment  = "prod"
aws_region   = "ap-south-1"
owner        = "platform-team"

# Networking
vpc_cidr             = "10.1.0.0/16"
availability_zones   = ["ap-south-1a", "ap-south-1b"]
public_subnet_cidrs  = ["10.1.1.0/24", "10.1.2.0/24"]
private_subnet_cidrs = ["10.1.10.0/24", "10.1.11.0/24"]
db_subnet_cidrs      = ["10.1.20.0/24", "10.1.21.0/24"]
enable_nat_gateway   = true
single_nat_gateway   = false  # High-availability in prod

# DNS / CloudFront
domain_name            = "example.com"
cloudfront_price_class = "PriceClass_200"
waf_rate_limit         = 2000

# ALB
alb_deletion_protection = true
alb_idle_timeout        = 60

# Frontend ASG
frontend_ami_id           = "ami-0c55b159cbfafe1f0"   # Replace with your AMI
frontend_instance_type    = "t3.small"
frontend_min_size         = 2
frontend_max_size         = 6
frontend_desired_capacity = 2
frontend_scale_out_cron   = "0 2 * * MON-FRI"    # 07:30 IST
frontend_scale_in_cron    = "0 15 * * MON-FRI"   # 20:30 IST

# Backend ASG
backend_ami_id            = "ami-0c55b159cbfafe1f0"   # Replace with your AMI
backend_instance_type     = "t3.medium"
backend_min_size          = 2
backend_max_size          = 8
backend_desired_capacity  = 2
backend_app_port          = 8080
backend_scale_out_cron    = "0 2 * * MON-FRI"
backend_scale_in_cron     = "0 15 * * MON-FRI"

# RDS
db_engine                = "mysql"
db_engine_version        = "8.0"
db_instance_class        = "db.t3.medium"
db_allocated_storage     = 50
db_max_allocated_storage = 200
db_name                  = "springbootdb"
db_username              = "admin"
db_multi_az              = true
db_backup_retention_period = 7
db_deletion_protection   = true

# S3
s3_force_destroy      = false
s3_versioning_enabled = true

# CloudWatch
log_retention_days  = 30
alarm_email         = "prod-alerts@example.com"
cpu_alarm_threshold = 75

# Slack
slack_channel = "#prod-alerts"

# Key Pair
key_pair_name = "springboot-prod-key"
